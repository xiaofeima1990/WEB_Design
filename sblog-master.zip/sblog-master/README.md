sblog
=====

一个使用django搭建的简易博客

前端使用bootstrap

Admin 使用grappelli优化
使用说明： http://django-grappelli.readthedocs.org/en/latest/

评论使用的系统自带comments

支持markdown

使用的gravatar头像服务
使用说明：http://en.gravatar.com/site/implement/images/django/

21/9/12

comments 添加了ajax支持
添加博客页面添加了添加标签
优化了界面

22/9/12

添加了增加多个标签 删除标签功能
添加了按标签检索功能


26/9/12
添加发布消息
添加代码高亮 使用markdown + Pygments
优化url
美化界面